<div class="updated wp_rp-updated" id="wp_rp-top-global-notice" >
	<div class="wp_rp-dismiss"><a href="<?php echo $close_url; ?>">Dismiss and go to settings</a></div>
	<h3><?php echo $notice['title']; ?></h3>
	<p class="wp_rp-about-description"><?php echo $notice['message']; ?></p>
</div>
