

<div class="<?php echo $type; ?>">
  
  <p>
    <strong><?php echo $message; ?></strong>
  </p>

</div>